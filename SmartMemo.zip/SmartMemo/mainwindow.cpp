#include "mainwindow.h"
#include"settings.h"
#include "ui_mainwindow.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setStyleSheet("background-color: rgb(255, 255, 255);");
    connect(ui->ViewmoreButton,SIGNAL(clicked()),this,SLOT(Open_Issue_of_Day()));
    connect(ui->settingsButton, &QPushButton::clicked, this, &MainWindow::SettingsButton_clicked);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::Open_Issue_of_Day(){
    Issues_of_Day* day_issues=new Issues_of_Day(this);
    day_issues->show();
}

void MainWindow::SettingsButton_clicked()
{
    Settings dialog(this);
    dialog.exec();
}

